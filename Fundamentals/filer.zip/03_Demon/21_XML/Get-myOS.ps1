$myXMLFile = "$PSScriptRoot\os.xml"
$xml = New-Object -TypeName XML
$xml.Load($myXMLFile)
($Xml.OSs.OS | where -Property Name -eq "Windows 7 x86").Collection

$myCollection = $Xml.OSs.OS | where -Property Name -eq "Windows 7 x86" | Select-Object -ExpandProperty Collection
$myCollection
