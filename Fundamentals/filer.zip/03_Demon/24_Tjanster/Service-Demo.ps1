$ServiceName = 'Bits'
$myService = Get-Service -Name $ServiceName

while ($myService.Status -ne 'Running')
{
    Start-Service $ServiceName
    write-Output $myService.status
    write-Output 'Service starting'
    Start-Sleep -seconds 20
    $myService.Refresh()
    if ($myService.Status -eq 'Running')
    {
        Write-Output 'Service is now Running'
    }
}