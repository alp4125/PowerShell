
$appInfoFile = "$PSScriptRoot\Application-Information.txt"
$applicationName = "Min applikation"
$applicationVersion = "1.0.0"
$applicationLanguage = "Svenska"

function Write-ApplicationInformation
{
	Param ([Parameter(Position = 1, Mandatory = $true)]
		$FilePath,
		[Parameter(Position = 2, Mandatory = $true)]
		$Property,
		[Parameter(Position = 3, Mandatory = $true)]
		$Value
	)
	
	switch ($Property)
	{
		"Application Name" { $myProperty = 'ApplicationName' }
		"Application Version" { $myProperty = 'ApplicationVersion' }
		"Application Language" { $myProperty = 'ApplicationLanguage' }
		"Application Vendor" { $myProperty = 'ApplicationVendor' }
		"Application Architecture" { $myProperty = 'ApplicationArchitecture' }
		"Application Description" { $myProperty = 'ApplicationDescription' }
		"Application GUID" { $myProperty = 'ApplicationGUID' }
		"Package Creator" { $myProperty = 'PackageCreator' }
		"Package Creation Date" { $myProperty = 'PackageCreationDate' }
		"Platforms Validated Windows 7 x86" { $myProperty = 'PlatformsValidatedW7x86' }
		"Platforms Validated Windows 7 x64" { $myProperty = 'PlatformsValidatedW7x64' }
		"Platforms Validated Windows 10 x86" { $myProperty = 'PlatformsValidatedW10x86' }
		"Platforms Validated Windows 10 x64" { $myProperty = 'PlatformsValidatedW10x64' }
	}
	
	(Get-Content $FilePath).replace($myProperty, $value) | Set-Content $FilePath
}



Write-ApplicationInformation -FilePath $appInfoFile -Property "Application Name" -Value $applicationName
Write-ApplicationInformation -FilePath $appInfoFile -Property "Application Version" -Value $applicationVersion
Write-ApplicationInformation -FilePath $appInfoFile -Property "Application Language" -Value $applicationLanguage
					