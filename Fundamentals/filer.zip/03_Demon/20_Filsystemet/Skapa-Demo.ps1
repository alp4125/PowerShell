﻿# Demo Skapa minakataloger.txt
# Övning 20 - Uppgift 2
Clear-Host
$minaKatalogerFil = "c:\scripts\minakataloger.txt"
$minaKataloger = "Bilder","Dokument","Foton","PowerShell"


if (!(Test-Path $minaKatalogerFil)) {
    Write-Output "Skapade filen"
    New-Item $minaKatalogerFil -Item file | Out-Null
}
else {
    Write-Output "Filen fanns redan"
}

foreach ($katalog in $minaKataloger) {
    Write-Output "Lägger till $katalog i $minakatalogerFil"
    Add-Content -Value $katalog -Path $minaKatalogerFil
}
