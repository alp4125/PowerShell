﻿$meddelande = "Mitt personnummer är 950212-00342"
$meddelande -replace '\d\d\d\d\d\d-\d\d\d\d', '######-####'