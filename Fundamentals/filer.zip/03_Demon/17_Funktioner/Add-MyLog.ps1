function Add-MyLog
	<#
		.SYNOPSIS
			Adding events to a log file
		
		.DESCRIPTION
			A detailed description of the Add-MyLog function.
		
		.PARAMETER Path
			Path to the log file
		
		.PARAMETER ComputerName
			The computer Name that was worked with
		
		.PARAMETER RunnedFrom
			The computer where the tool was started from
	
		
		.PARAMETER RunnedBy
			The user who started the tool
		
		.PARAMETER Event
			What was done
		
		.NOTES
			Author:          Fredrik Wall
	        Email:           fredrik.wall@retune.se
	        Company:         Retune AB
	        Created:         2011-03-05
	        Updated:         2018-02-17
	#>
	{
		[CmdletBinding()]
		param
		(
			$Path,
			$ComputerName,
			$RunnedFrom,
			$RunnedBy,
			$Event
		)
		
		$logFile = "$Path\$ComputerName.log"
		
		if (!(Test-Path $logFile))
		{
			"Date;ComputerName;RunnedFrom;RunnedBy;Event" | Out-File $logFile
		}
		
		$myTime = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
		
		$myLogLine = $myTime + ";" + $RunnedFrom + ";" + $RunnedBy + ";" + $Event
		
		$myLogLine | Out-File $logFile -Append
		
    }
    $myPath = "c:\scripts"
    $test = $false

    if ($test -eq $true) {
        Add-MyLog -Path $myPath -ComputerName "lon-dc1" -RunnedFrom "$($env:COMPUTERNAME)" -RunnedBy "$($env:USERNAME)" -Event "Test OK"
    }
    else {
        Add-MyLog -Path $myPath -ComputerName "lon-dc1" -RunnedFrom "$($env:COMPUTERNAME)" -RunnedBy "$($env:USERNAME)" -Event "Test Inte OK"
    }