function Invoke-DownloadApplication
{
		<#
		.SYNOPSIS
			Download application
		
        .DESCRIPTION
			Download application
		
        .PARAMETER Url
			URL to the application to be downloaded
		
        .PARAMETER Destination
			Destionation of the application
		
        .EXAMPLE
			Download-Application -URL "https://www.apple.com/itunes/download/win64" -Destination "c:\temp\applicationname.exe"
		
		.NOTES
			Author: 	Fredrik Wall
			Email:		fredrik.wall@retune.se
			Created:	2018-11-08
	        Version:    1.0
		#>
	
	Param ([Parameter(Position = 1, Mandatory = $true)]
		$URL,
		[Parameter(Position = 2, Mandatory = $true)]
		$Destination
	)
	
	try
	{
		$ProgressPreference = 'SilentlyContinue'
		Invoke-WebRequest -Uri $URL -OutFile $destination -ErrorAction Stop
		$ProgressPreference = 'Continue'
	}
	catch
	{
		Write-Warning "Can't download application"
		Break
	}
}