﻿Clear-Host
# Import settings from settings file
try
{
    $Settings = Import-PowerShellDataFile "$PSScriptRoot\Settings.psd1"
}
catch
{
    Write-Output "Could not load settings file"
    Break
}

$DownloadFolder = "$($PSScriptRoot)\$($Settings.DownloadFolder)"
$LogsFolder = "$($PSScriptRoot)\$($Settings.LogsFolder)"
$TempFolder = "$($PSScriptRoot)\$($Settings.TempFolder)"

Write-Output "Download folder: $DownloadFolder"
Write-Output "Logs folder: $LogsFolder"
Write-Output "Temp folder: $TempFolder"

$ResaApplication = @()

foreach ($Application in $Settings.Applications) {
	
		
	$ApplicationObject = [PSCustomObject] @{    
		ApplicationName = $Application.ApplicationName
		Architecture = $Application.Architecture
		Language = $Application.Language
		Description = $Application.Description
		FileName = $Application.FileName
		Download = $Application.Download
		UpdatePackage = $Application.UpdatePackage
		DownloadUrl = $Application.DownloadUrl
		DownloadVersionControl = $Application.DownloadVersionControl
	}

	$ResaApplication += $ApplicationObject
}
	
Write-Output $ResaApplication
